`use strict`;

import { authView } from './auth.js';
authView();

import Alpine from 'alpinejs';
Alpine.start()