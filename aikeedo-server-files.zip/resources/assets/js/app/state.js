'use strict';

import Alpine from 'alpinejs';

export function initState() {
    Alpine.store('presets', []);
}