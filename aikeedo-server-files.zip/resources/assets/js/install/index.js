'use strict';

import Alpine from 'alpinejs';
import { installerView } from './installer.js';

installerView();
Alpine.start();