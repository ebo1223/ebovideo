<?php

declare(strict_types=1);

namespace Ai\Domain\Exceptions;

use Exception;

class ApiException extends Exception
{
}
