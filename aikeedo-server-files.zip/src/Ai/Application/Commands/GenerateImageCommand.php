<?php

namespace Ai\Application\Commands;

class GenerateImageCommand
{
}
