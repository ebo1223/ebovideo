<?php

declare(strict_types=1);

namespace Document\Domain\Events;

/**
 * @package Document\Domain\Events
 */
class DocumentDeletedEvent extends AbstractDocumentEvent
{
}
