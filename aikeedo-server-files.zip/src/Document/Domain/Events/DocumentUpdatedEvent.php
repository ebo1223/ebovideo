<?php

declare(strict_types=1);

namespace Document\Domain\Events;

/**
 * @package Document\Domain\Events
 */
class DocumentUpdatedEvent extends AbstractDocumentEvent
{
}
