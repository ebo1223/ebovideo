<?php

declare(strict_types=1);

namespace Billing\Domain\Events;

/**
 * @package Plan\Domain\Events
 */
class PlanDeletedEvent extends AbstractPlanEvent
{
}
