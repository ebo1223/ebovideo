<?php

declare(strict_types=1);

namespace Billing\Domain\Events;

/** @package Billing\Domain\Events */
class SubscriptionUsageResetEvent extends AbstractSubscriptionEvent
{
}
