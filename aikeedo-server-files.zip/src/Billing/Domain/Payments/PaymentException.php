<?php

namespace Billing\Domain\Payments;

use Exception;

class PaymentException extends Exception
{
}
