<?php

declare(strict_types=1);

namespace Preset\Domain\Exceptions;

use Exception;

/** @package Preset\Domain\Exceptions */
class LockedPresetException extends Exception
{
}
