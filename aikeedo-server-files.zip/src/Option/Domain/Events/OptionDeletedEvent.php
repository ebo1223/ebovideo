<?php

declare(strict_types=1);

namespace Option\Domain\Events;

/**
 * @package Option\Domain\Events
 */
class OptionDeletedEvent extends AbstractOptionEvent
{
}
